-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2022 at 06:02 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `DBid` int(11) NOT NULL,
  `DBfirstname` tinytext NOT NULL,
  `DBlastname` tinytext NOT NULL,
  `DBusername` tinytext NOT NULL,
  `DBpassword` longtext NOT NULL,
  `DBemail` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`DBid`, `DBfirstname`, `DBlastname`, `DBusername`, `DBpassword`, `DBemail`) VALUES
(40, 'moe', 'khaled', 'mhd', '$2y$10$zQjLTTuEydNCNH4SNWKsS.hL5MngwerkV7KXoKcB6qRJbsc7etUsi', 'mhdoo024'),
(41, '3213', '321321', '321312', '$2y$10$AEKrSFNm6zVKBYp6ilnhZ.Bn5zamyaT1OftHgG2.B4bRXO9ySsxs2', '321312'),
(42, 'dsad', 'dasda', '31213', '$2y$10$HTXuLe/cj.gfYHVqFrAM4ei.w/MQCtwZmyOad6bO7npT8Eq3YaWCO', 'dsadasd'),
(43, 'ahmad', 'asdad', '123', '$2y$10$/pRUTWVj2U2IsuCTCbPtBeBmLXRHX6wIQS0lLt/0xZ/fjK8MRHoiK', 'dsaplda'),
(44, 'fahed', 'ahmad', 'fahed', '$2y$10$AQAEoa7P/FcDQrmVPw048OYW5VvRKpe6m6dPnoM9I/3R1AveYNn5.', 'mhas'),
(45, 'ali', 'alawneh', 'ali alawneh', '$2y$10$CGLbcp6iYrUK.VcRWMpjx.GgaMa.35dyM03YUd1gPn/4d5mYvSQ1a', 'ali @gmail.com'),
(46, 'moe', 'sal', 'moe', '$2y$10$U8tO7u0Lw0D1H.Fyww5FAOjtn7pc/3kjdKiUHEoJhs8llDfWwwSjy', 'dsada'),
(47, 'mhd', 'saleh', 'mhd123', '$2y$10$byxGqLyTlGGtcxOHCR9Ykectd.N5qZgMeUolyI70SLXeaIAWgn4cq', 'mhdakoask'),
(48, 'amro', 'amro', 'amro', '$2y$10$ZecJdBo2S.9up5Qv.7zsSe7HF4n2iZUY2ireT2RsDlD73.y1Vm5/O', 'msdao');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`DBid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `DBid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
